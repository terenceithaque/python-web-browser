/ Navigateur web test construit avec python selon le code de la vidéo https://www.youtube.com/watch?v=u8IsuRT6ZBs
